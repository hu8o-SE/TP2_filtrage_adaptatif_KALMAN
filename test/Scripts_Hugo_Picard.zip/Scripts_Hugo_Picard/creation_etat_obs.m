function [x_list,y_list]=creation_etat_obs(F,C,Ru,Rw,x1,T)

% function [x_list,y_list]=creation_etat_obs(F,C,Ru,Rw,x1,T)
%
% Cette fonction g�n�re des �tats (qui sont cach�s) et des observations suivant le mod�le d'�tat : 
%   x(n+1) = F x(n) + u(n), o� u est un vecteur al�atoire gaussien centr� de matrice de covariance Ru
%   y(n) = C x(n) + w(n), o� w est un vecteur al�atoire gaussien centr� de matrice de covariance Rw
% o� on suppose que les matrices F, C, Ru et Rw ne varient pas au cours du temps.
%
% Variables d'entr�e :
% -	les matrices F, C, Ru et Rw du mod�le d'�tat, 
% - x1 le vecteur d'�tat initial (� l'instant n=1), 
% - T le nombre total d'instants souhait� (correspondant au nombre d'observations souhait�).
%
% Variables de sortie :
% -	x_list est la matrice contenant la suite des �tats (autrement dit, la ni�me colonne de cette matrice contiendra l'�tat � l'instant n),
% -	y_list est la matrice contenant la suite des observations (autrement dit, la ni�me colonne de cette matrice contiendra l'observation � l'instant n).

[N,M]=size(C);

if Ru==zeros(M,M),
    u_list=zeros(M,T);
else 
    [Lu,p]=chol(Ru,'lower');
    if p==0,
        u_list=Lu*randn(M,T);
    else
        error('La matrice Ru doit etre definie positive.')
    end
end

if Rw==zeros(N,N),
    w_list=zeros(N,T);
else 
    [Lw,p]=chol(Rw,'lower');
    if p==0,
        w_list=Lw*randn(N,T);
    else
        error('La matrice Rw doit etre definie positive.')
    end
end

x_list=zeros(M,T);
y_list=zeros(N,T);
x_list(:,1)=x1;
y_list(:,1)=C*x_list(:,1)+w_list(:,1);
for n=2:T,
    x_list(:,n)=F*x_list(:,n-1)+u_list(:,n-1);
    y_list(:,n)=C*x_list(:,n)+w_list(:,n);
end

