clear all; close all; clc;

% Test de la fonction filtre_kalman quand la position ET la vitesse sont observées
%-------------------------------------------------------------------------------

Te = 1;

% Modèle d'état : x(n+1) = F x(n) + u(n)
F = [1 Te;
     0 1];

% Observation complète : y(n) = C x(n) + w(n)
C = eye(2);

% Etat initial : position 0 m, vitesse 50 m/s
x1 = [0 ; 50];
v1 = x1(2);

T = 100;   % nombre d'instants (donc d'observations)

% Initialisations du filtre
x_prio_1 = x1;
P_prio_1 = 10*eye(2);

% Choix des RSB (garde les mêmes que le scénario "position seule" pour comparer)
RSB_etat   = 50;   % en dB
RSB_mesure = 50;   % en dB

% Déduction des écarts-types à partir du RSB (référence = v1)
sigma_u = v1 * 10^(-RSB_etat/20);
sigma_w = v1 * 10^(-RSB_mesure/20);

% Covariances des bruits
Ru = diag([sigma_u^2 sigma_u^2]);        % bruit modèle sur position et vitesse
Rw = diag([sigma_w^2 sigma_w^2]);        % bruit mesure sur position et vitesse

% Génération états/observations
[x_list, y_list] = creation_etat_obs(F, C, Ru, Rw, x1, T);

% Filtrage de Kalman
% (ordre des sorties = [G_list, x_post_list, P_post_list, x_prio_list, P_prio_list])
[G_list, x_post_list, P_post_list, x_prio_list, P_prio_list] = ...
    filtre_kalman(x_prio_1, P_prio_1, y_list, F, C, Ru, Rw);

% On garde les T premiers "a priori" (car x_prio_list contient T+1 colonnes)
x_prio_list = x_prio_list(:,1:T);
P_prio_list = P_prio_list(:,:,1:T);

n = 1:T;

%% Figure 1 : états / observations / estimations
figure;

subplot(211);
plot(n, x_list(1,:), 'k+', n, y_list(1,:), 'g*', ...
     n, x_prio_list(1,:), 'bo', n, x_post_list(1,:), 'rx');
legend('position vraie','position observée','estimée a priori','estimée a posteriori');
xlabel('temps en secondes'); ylabel('position en mètres');
title('Position');

subplot(212);
plot(n, x_list(2,:), 'k+', n, y_list(2,:), 'g*', ...
     n, x_prio_list(2,:), 'bo', n, x_post_list(2,:), 'rx');
legend('vitesse vraie','vitesse observée','estimée a priori','estimée a posteriori');
xlabel('temps en secondes'); ylabel('vitesse en m/s');
title('Vitesse');

%% Figure 2 : erreurs (et bruits de mesure)
figure;

subplot(211);
plot(n, x_list(1,:)-y_list(1,:), 'g*', ...
     n, x_list(1,:)-x_prio_list(1,:), 'bo', ...
     n, x_list(1,:)-x_post_list(1,:), 'rx');
legend('bruit mesure position','erreur position a priori','erreur position a posteriori');
xlabel('temps en secondes'); ylabel('mètres');

subplot(212);
plot(n, x_list(2,:)-y_list(2,:), 'g*', ...
     n, x_list(2,:)-x_prio_list(2,:), 'bo', ...
     n, x_list(2,:)-x_post_list(2,:), 'rx');
legend('bruit mesure vitesse','erreur vitesse a priori','erreur vitesse a posteriori');
xlabel('temps en secondes'); ylabel('m/s');

%% Figure 3 : évolution des variances (diagonales des covariances)
P_prio_11 = squeeze(P_prio_list(1,1,:));
P_prio_22 = squeeze(P_prio_list(2,2,:));
P_post_11 = squeeze(P_post_list(1,1,:));
P_post_22 = squeeze(P_post_list(2,2,:));

figure;

subplot(211);
plot(n, P_prio_11, 'b', n, P_post_11, 'r');
legend('P a priori (1,1)','P a posteriori (1,1)');
xlabel('temps en secondes');
title('Variance sur la position');

subplot(212);
plot(n, P_prio_22, 'b', n, P_post_22, 'r');
legend('P a priori (2,2)','P a posteriori (2,2)');
xlabel('temps en secondes');
title('Variance sur la vitesse');

%% Figure 4 : trajectoires estimées dans l'espace d'état + ellipses de confiance
figure;
hold on; grid on; axis equal;
title('Estimées a priori / a posteriori + ellipses (eta = 0.9)');
xlabel('x_1 (position)'); ylabel('x_2 (vitesse)');

plot(x_prio_list(1,:), x_prio_list(2,:), 'bo');
plot(x_post_list(1,:), x_post_list(2,:), 'rx');

eta = 0.9;
for k = 1:T
    trace_ellipse(x_prio_list(:,k), P_prio_list(:,:,k), eta, 'b');
    trace_ellipse(x_post_list(:,k), P_post_list(:,:,k), eta, 'r');
end

legend('estimée a priori','estimée a posteriori');
hold off;
